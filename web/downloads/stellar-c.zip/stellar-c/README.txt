STELLAR C - the compiler, to run on your own computer
=====================================================

Stellar C is a small C-like language that compiles to STELLAR bytecode for the RCA 1802
(STELLAR-1802 on a COSMAC Elf 2000). This is the same compiler the Stellar C page at
https://stellar-1802.dev/stellarc runs in the browser.

WHAT YOU NEED
  Python 3.8 or newer. Nothing else - no packages to install.

COMPILE A PROGRAM
  cd stellar-c
  python3 scc.py examples/hello.sc

  This writes examples/hello.lst (the program, ready to load) and examples/hello.sym.json
  (where each function and variable ended up). To name the output yourself:

  python3 scc.py myprog.sc -o myprog.lst

  If the program has a mistake, the compiler prints the line number and what is wrong, and
  writes nothing.

RUN IT
  On an Elf2K: the .lst starts with a commented disassembly (every line begins with ';', so
  the loader skips it), then the block of 'D aaaa bb bb ...' lines. Send the whole file to the
  Elf2K's monitor from your terminal program, the same way as any other STELLAR .lst, and
  start STELLAR. STELLAR firmware V0061.35 or later is needed (rtcget/rtcset use its $07
  clock opcode).

  In a browser: open https://stellar-1802.dev/simulator and use "Open .lst", or paste the
  source into https://stellar-1802.dev/stellarc and press Compile, then Run.

LEARN THE LANGUAGE
  GUIDE.md is the language, step by step, from the first program to a finished game. Every
  example in it is in guide-examples/ and was checked by compiling and running it. The same
  guide, with Try-it links, is at https://stellar-1802.dev/stellarc-guide

FILES
  scc.py              the compiler (run this one)
  asm1802.py          its 1802 assembler, for native { } blocks
  mini.py             its STELLAR assembler
  stellar_ops.py      the STELLAR commands it emits
  stellar_disasm.py   STELLAR command lengths and names
  examples/           the example programs from the Stellar C page
  guide-examples/     every runnable example from GUIDE.md
  GUIDE.md            the guide

Stellar C is a prototype and the language is still growing; the newest version is always on
the Stellar C page.
