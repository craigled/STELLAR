THE ELF2K CARD TOOL
===================

Looks after the CompactFlash card in an Elf 2000 (Elf2K) with the Disk/UART/RTC card, over its serial port:

   1  Format a card and install LTOS + STELLAR          7  List every file on the card
   2  Update LTOS + STELLAR (only what differs)          8  Get a file from the card
   3  Back up the card to this computer                  9  Put a file on the card
   4  Check the card (FSCK, space, bad clusters)        10  Restore a backup onto a card
   5  Name this card                                    11  Delete a file or folder
   6  Arrange the programs into /BIN, /BIN/GAMES ...    12  Run a raw 1802 program

This copy holds LTOS 0.5 (kernel built 2026-11-27 21:26) and STELLAR V0061.37.
Backups go to the folder Elf2K-backups in your home folder; files got from the card go to Downloads.


WHAT YOU NEED
-------------
  * An Elf2K with the STELLAR ROM and a CF card, on a USB serial cable at 19200 baud, 8N1.
  * Python 3 (3.8 or newer).
  * Nothing else may be using the serial port: close any terminal program first.


ON A MAC
--------
  1. Unzip, and keep the Elf2K-Card-Tool folder where you like (Documents, the Desktop ...).
  2. Python 3: type  python3 --version  in Terminal. If it is missing, macOS offers to install the
     command line tools - say yes - or get Python from python.org.
  3. Double-click "Elf2K Card.command". The first time macOS may refuse a downloaded script:
     right-click it, choose Open, then Open again. (Or in Terminal:  xattr -dr com.apple.quarantine
     followed by the folder.)
  The USB serial port is found by itself. With more than one plugged in, run it from Terminal with
     ./elf2k-card.sh --port /dev/cu.usbserial-XXXX


ON WINDOWS
----------
  1. Unzip (right-click, Extract All), and keep the Elf2K-Card-Tool folder where you like.
  2. Install Python 3 from python.org - tick "Add python.exe to PATH" - or from the Microsoft Store.
  3. Double-click "Elf2K Card.bat". The first time it installs pyserial (the serial port library).
     If Windows SmartScreen warns about the file: More info, then Run anyway.
  The one USB serial port is found by itself. With more than one: open a Command Prompt in the folder
  and type   "Elf2K Card.bat" --port COM4   (Device Manager, Ports, shows which COM it is).


ON LINUX
--------
  ./elf2k-card.sh   (the port is found by itself, or --port /dev/ttyUSB0)
  Your user needs to be allowed the serial port: on most systems  sudo usermod -aG dialout $USER
  then log out and in again.


GOOD TO KNOW
------------
  * A card that already holds LTOS is never formatted without asking - twice - and a backup is offered.
  * Update sends only what differs from this copy: the kernel, system files and STELLAR.BIN.
  * Your own files are never moved or replaced unless you say so.
  * Esc leaves every LTOS program; if the Elf2K stops answering, press its Reset and pick R (read again).

LTOS and STELLAR are by Craig Ledbetter. Free software: GPL-3.0-or-later (COPYING).
Source, a version that runs in a web browser, and one for the Emma 02 emulator:
github.com/craigled/STELLAR
